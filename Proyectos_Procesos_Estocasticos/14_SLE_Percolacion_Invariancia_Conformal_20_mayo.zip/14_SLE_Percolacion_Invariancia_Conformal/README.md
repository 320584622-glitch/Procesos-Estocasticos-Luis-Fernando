# Percolacion critica, invariancia conforme y SLE

Proyecto avanzado para la materia de Procesos Estocasticos.

## Objetivo

Presentar una investigacion tipo tesis sobre percolacion critica, transicion de fase, invariancia conforme y evolucion de Schramm-Loewner (SLE), conectando simulacion computacional con teoria probabilistica moderna.

## Archivos

- `presentacion_sle_percolacion.tex`: presentacion formal en LaTeX Beamer.
- `presentacion_sle_percolacion.pdf`: version compilada para presentar.
- `simulacion_percolacion.py`: simulacion Monte Carlo de percolacion por sitios.
- `figures/`: graficas generadas por la simulacion.

## Temas

- Percolacion por sitios.
- Valor critico y transicion de fase.
- Probabilidad de cruce.
- Limite de escala.
- Invariancia conforme.
- Formula de Cardy.
- Evolucion de Schramm-Loewner SLE.

## Como ejecutar la simulacion

```bash
python simulacion_percolacion.py
```

## Como compilar la presentacion

```bash
pdflatex presentacion_sle_percolacion.tex
pdflatex presentacion_sle_percolacion.tex
```
