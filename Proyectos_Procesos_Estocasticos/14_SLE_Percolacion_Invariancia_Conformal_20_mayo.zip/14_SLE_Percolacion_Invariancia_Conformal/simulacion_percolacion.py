"""
Simulacion de percolacion por sitios en una red cuadrada.
Proyecto: Percolacion critica, invariancia conformal y SLE.
Autor: Romero Velazquez Luis Fernando

Este script genera:
1) Una red de percolacion para visualizar sitios abiertos/cerrados.
2) Una estimacion Monte Carlo de la probabilidad de cruce izquierda-derecha.
"""

from collections import deque
import numpy as np
import matplotlib.pyplot as plt


def existe_cruce(red: np.ndarray) -> bool:
    """Regresa True si existe un camino abierto de izquierda a derecha."""
    n, m = red.shape
    visitado = np.zeros_like(red, dtype=bool)
    cola = deque()

    for i in range(n):
        if red[i, 0]:
            cola.append((i, 0))
            visitado[i, 0] = True

    vecinos = [(1, 0), (-1, 0), (0, 1), (0, -1)]
    while cola:
        i, j = cola.popleft()
        if j == m - 1:
            return True
        for di, dj in vecinos:
            ni, nj = i + di, j + dj
            if 0 <= ni < n and 0 <= nj < m:
                if red[ni, nj] and not visitado[ni, nj]:
                    visitado[ni, nj] = True
                    cola.append((ni, nj))
    return False


def experimento(n: int, p: float, repeticiones: int, semilla: int = 7) -> float:
    """Estima la probabilidad de cruce para una red n x n y parametro p."""
    rng = np.random.default_rng(semilla)
    exitos = 0
    for _ in range(repeticiones):
        red = rng.random((n, n)) < p
        exitos += int(existe_cruce(red))
    return exitos / repeticiones


def main():
    rng = np.random.default_rng(123)
    n_visual = 90
    p_visual = 0.5
    red = rng.random((n_visual, n_visual)) < p_visual

    plt.figure(figsize=(6, 6))
    plt.imshow(red, interpolation="nearest")
    plt.title("Percolacion por sitios: red aleatoria con p=0.5")
    plt.axis("off")
    plt.tight_layout()
    plt.savefig("figures/percolacion_red.png", dpi=220)
    plt.close()

    ps = np.linspace(0.35, 0.65, 13)
    probs = [experimento(n=45, p=float(p), repeticiones=250, semilla=100 + k) for k, p in enumerate(ps)]

    plt.figure(figsize=(7, 4))
    plt.plot(ps, probs, marker="o")
    plt.axvline(0.5, linestyle="--", label="referencia p=0.5")
    plt.xlabel("Probabilidad de sitio abierto p")
    plt.ylabel("Probabilidad estimada de cruce")
    plt.title("Transicion de fase en percolacion")
    plt.legend()
    plt.tight_layout()
    plt.savefig("figures/percolacion_transicion.png", dpi=220)
    plt.close()


if __name__ == "__main__":
    main()
