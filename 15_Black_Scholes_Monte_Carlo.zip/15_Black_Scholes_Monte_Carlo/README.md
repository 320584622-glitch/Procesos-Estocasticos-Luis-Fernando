# Movimiento Browniano Geométrico y Simulación Monte Carlo

Este proyecto presenta una aplicación avanzada de procesos estocásticos al modelo financiero de Black--Scholes.

## Objetivo

Estudiar el movimiento browniano geométrico, explicar su relación con el modelo de Black--Scholes y construir una simulación Monte Carlo para analizar trayectorias de precios, distribución final y valuación básica de una opción call europea.

## Contenido

- `investigacion_black_scholes.tex`: documento formal en LaTeX tipo investigación.
- `investigacion_black_scholes.pdf`: versión compilada del documento.
- `presentacion_black_scholes.tex`: presentación en Beamer.
- `presentacion_black_scholes.pdf`: presentación compilada.
- `simulacion_black_scholes.py`: código Python para generar simulaciones y gráficas.
- `simulacion_black_scholes.ipynb`: notebook para ejecutar el proyecto en Google Colab.
- `graficas/`: imágenes generadas por la simulación.

## Temas principales

- Movimiento browniano estándar.
- Movimiento browniano geométrico.
- Fórmula de Itô.
- Modelo de Black--Scholes.
- Simulación Monte Carlo.
- Distribución lognormal.
- Valuación de opciones europeas.

## Modelo matemático

El precio del activo se modela mediante:

```math
 dS_t = \mu S_t\,dt + \sigma S_t\,dB_t
```

cuya solución explícita es:

```math
 S_t = S_0\exp\left[\left(\mu-\frac{\sigma^2}{2}\right)t+\sigma B_t\right].
```

Para una opción call europea, el pago final es:

```math
 (S_T-K)^+=\max(S_T-K,0).
```

## Resultados de la simulación

Con 20,000 trayectorias simuladas se obtuvo:

- Media empírica de `S_T`: 110.3880.
- Media teórica de `S_T`: 110.5171.
- Probabilidad estimada de terminar con ganancia: 0.6121.
- Precio Monte Carlo estimado de una call europea: 12.7972.
- Error estándar Monte Carlo: 0.1362.

## Ejecución

Para ejecutar el código:

```bash
python simulacion_black_scholes.py
```

El script genera automáticamente las gráficas en la carpeta `graficas/`.

## Autor

Romero Velázquez Luis Fernando  
Materia: Procesos Estocásticos  
UNAM FES Acatlán
