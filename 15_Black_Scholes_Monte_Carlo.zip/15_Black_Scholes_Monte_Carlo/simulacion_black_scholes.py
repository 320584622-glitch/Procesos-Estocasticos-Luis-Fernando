"""
Simulacion Monte Carlo del Movimiento Browniano Geometrico
Proyecto: Procesos Estocasticos - Black-Scholes / Monte Carlo
Autor: Romero Velazquez Luis Fernando

Este script genera trayectorias de precios bajo el modelo:
    dS_t = mu S_t dt + sigma S_t dB_t
cuya solucion exacta es:
    S_t = S_0 exp((mu - sigma^2/2)t + sigma B_t)

Tambien estima el precio de una opcion call europea usando Monte Carlo:
    C_0 = exp(-rT) E[(S_T - K)^+]
"""

import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path

np.random.seed(42)

# Carpeta de salida para graficas
OUT_DIR = Path("graficas")
OUT_DIR.mkdir(exist_ok=True)

# Parametros del modelo
S0 = 100.0      # precio inicial
mu = 0.10      # rendimiento esperado anual
sigma = 0.25   # volatilidad anual
r = 0.05       # tasa libre de riesgo
T = 1.0        # horizonte en anos
K = 105.0      # precio de ejercicio de la opcion
n_steps = 252  # dias habiles aproximados
n_paths = 20000

# Mallado temporal
dt = T / n_steps
t = np.linspace(0, T, n_steps + 1)

# Simulacion de incrementos brownianos
dW = np.sqrt(dt) * np.random.normal(size=(n_paths, n_steps))
W = np.cumsum(dW, axis=1)
W = np.column_stack([np.zeros(n_paths), W])

# Solucion exacta del movimiento browniano geometrico
S = S0 * np.exp((mu - 0.5 * sigma**2) * t + sigma * W)

# Grafica 1: algunas trayectorias
plt.figure(figsize=(9, 5))
for i in range(60):
    plt.plot(t, S[i], linewidth=0.8, alpha=0.65)
plt.xlabel("Tiempo (anos)")
plt.ylabel("Precio simulado S(t)")
plt.title("Trayectorias simuladas del movimiento browniano geometrico")
plt.grid(True, alpha=0.25)
plt.tight_layout()
plt.savefig(OUT_DIR / "trayectorias_mbg.png", dpi=180)
plt.close()

# Grafica 2: distribucion de precios finales
ST = S[:, -1]
plt.figure(figsize=(9, 5))
plt.hist(ST, bins=70, density=True, alpha=0.75)
plt.axvline(ST.mean(), linestyle="--", linewidth=2, label=f"Media empirica = {ST.mean():.2f}")
plt.axvline(S0, linestyle=":", linewidth=2, label=f"Precio inicial = {S0:.0f}")
plt.xlabel("Precio final S(T)")
plt.ylabel("Densidad estimada")
plt.title("Distribucion empirica de precios finales")
plt.legend()
plt.grid(True, alpha=0.25)
plt.tight_layout()
plt.savefig(OUT_DIR / "histograma_precios_finales.png", dpi=180)
plt.close()

# Grafica 3: probabilidad acumulada de ganancia S_T > S0 por numero de simulaciones
indicador_ganancia = (ST > S0).astype(float)
prob_acum = np.cumsum(indicador_ganancia) / np.arange(1, n_paths + 1)
plt.figure(figsize=(9, 5))
plt.plot(np.arange(1, n_paths + 1), prob_acum, linewidth=1.2)
plt.xlabel("Numero de simulaciones")
plt.ylabel("Estimacion acumulada P(S_T > S_0)")
plt.title("Convergencia Monte Carlo de la probabilidad de ganancia")
plt.grid(True, alpha=0.25)
plt.tight_layout()
plt.savefig(OUT_DIR / "probabilidad_ganancia.png", dpi=180)
plt.close()

# Precio Monte Carlo de call europea
payoff_call = np.maximum(ST - K, 0)
precio_call_mc = np.exp(-r * T) * payoff_call.mean()
error_estandar = np.exp(-r * T) * payoff_call.std(ddof=1) / np.sqrt(n_paths)
prob_ganancia = (ST > S0).mean()
prob_call_itm = (ST > K).mean()
media_teorica_ST = S0 * np.exp(mu * T)
var_teorica_ST = S0**2 * np.exp(2*mu*T) * (np.exp(sigma**2*T) - 1)

print("Resultados principales")
print("----------------------")
print(f"Precio inicial S0: {S0:.2f}")
print(f"Media empirica de S_T: {ST.mean():.4f}")
print(f"Media teorica de S_T: {media_teorica_ST:.4f}")
print(f"Varianza empirica de S_T: {ST.var(ddof=1):.4f}")
print(f"Varianza teorica de S_T: {var_teorica_ST:.4f}")
print(f"P(S_T > S0): {prob_ganancia:.4f}")
print(f"P(S_T > K): {prob_call_itm:.4f}")
print(f"Precio Monte Carlo de call europea: {precio_call_mc:.4f}")
print(f"Error estandar Monte Carlo: {error_estandar:.4f}")
